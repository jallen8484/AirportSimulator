/**
 * @project AirportSimulator
 * @package airportSimulator.model
 * @author Brian Bagley
 * @author David Cook
 * @author Jeremy Allen
 * @author Joshua Charles
 * @version 3.0
 */
package airportSimulator.model;

// TODO: Auto-generated Javadoc
/**
 * The Class AirplaneContainer.
 * @author Jeremy Allen
 * @version 3.0
 */
public class AirplaneContainer extends VehicleContainer {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8968979703937055246L;

}
