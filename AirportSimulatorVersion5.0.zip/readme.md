This is a merge of Version 3.1 from github and my Version 4.0


4-30-2011 : 11:15am : Josh Charles
	Added my class diagram to the project and updated

4-30-2011 : 11:00am : Josh Charles
	Updated files to get the bugs fixed, code now compiles and does
	not throw any exceptions like my version 4.0.

4-30-2011 : 8:00am : Josh Charles
	merged, compiled, executed but with errors
	still need to merge AirportSimulatorModel.java
